package iss.java.mail;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;
import com.sun.mail.imap.IMAPMessage;

/**
 * 简易邮件客户端雏形
 * @author 2014302580338
 *
 */
public class MailService2014302580338 implements IMailService {
	
	private final String USER="javamail338@sina.com";
	private final String PASSWORD="jm338t";
	
	
   
    /**
     * 邮箱session
     */
    private transient Transport transport;
    private transient Store store;
    private transient Session sesession;
    private Folder folder;
	
	/**
     * 初始化并连接所有的邮件服务器
     * @throws MessagingException 初始化或连接异常
     */

	@Override
	public void connect() throws MessagingException {
		/**
		 * 连接到SMTP邮件服务器
		 */
			Properties seprops=new Properties();
		   	seprops.setProperty("mail.transport.protocol", "smtp");  
	        seprops.setProperty("mail.smtp.host", "smtp.sina.com");  
	        seprops.setProperty("mail.smtp.port", "25");  
	        seprops.setProperty("mail.smtp.auth", "true");  
	        seprops.setProperty("mail.debug","true"); 
	        sesession= Session.getInstance(seprops);
	        transport = sesession.getTransport();
	        transport.connect(USER,PASSWORD); 
		
		/**
		 * 连接到IMAP邮件服务器并获取收件箱
		 */
		
		Properties reprops=new Properties();
		reprops.setProperty("mail.store.protocol", "imap");  
        reprops.setProperty("mail.imap.host", "imap.sina.com");  
        Session resession=Session.getInstance(reprops);
		store=resession.getStore();
		store.connect("imap.sina.com",USER,PASSWORD);
		 folder = store.getFolder("INBOX");
		 folder.open(Folder.READ_ONLY);
	}
	
	/**
     * 发送单封邮件
     * @param recipient 收件人邮箱地址
     * @param subject 邮件主题
     * @param content 邮件正文
     * @throws MessagingException 发送邮件错误
     */

	@Override
	public void send(String recipient, String subject, Object content) throws MessagingException {
		// TODO Auto-generated method stub
		// 创建mime类型邮件
        MimeMessage message = new MimeMessage(sesession);
        // 设置发信人
        message.setFrom(new InternetAddress(USER));
        // 设置收件人
        message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
        // 设置主题
        message.setSubject(subject);
        // 设置邮件内容
        message.setContent(content.toString(), "text/html;charset=utf-8");
         
        // 将message对象传递给transport对象，将邮件发送出去  
        transport.sendMessage(message, message.getAllRecipients());  
        // 关闭连接  
        transport.close();  
       
	}
	
	 /**
     * 询问服务器是否有新邮件到达
     * @return 布朗值，指示是否有新邮件
     * @throws MessagingException 询问服务器出错
     */

	@Override
	public boolean listen() throws MessagingException {
          
      return folder.hasNewMessages();
	}
	
	 /**
     * 接收自动回复的内容，并转换为字符串
     * @param sender 自动回复的发件人邮箱地址
     * @param subject 自动回复的主题
     * @return 自动回复的内容字符串
     * @throws MessagingException 查询邮件异常
     * @throws IOException 下载邮件异常
     */

	@Override
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
	
		String  reply=new String();
		            
        // 获得收件箱的邮件列表  
        Message[] messages = folder.getMessages() ;
          
       //获得自动回复邮件
         IMAPMessage msg = (IMAPMessage) messages[messages.length-1];
         reply+=msg.getContent().toString();
         
           
        //关闭资源
        folder.close(true);
        store.close();
        return reply;
	}

}
